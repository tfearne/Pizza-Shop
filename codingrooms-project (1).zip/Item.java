public class Item {
    int id;
    String name;
    double price;

    public Item(int i, String n, double p) {
        id = i;
        name = n;
        price = p;
    }
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public double getPrice() {
        return price;
    }
    public String toString() {
        return String.format("%d. %s\t$%.2f", id, name, price);
    }
}