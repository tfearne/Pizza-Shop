import java.util.Scanner;

public class FearneTylerBusinessDriver {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        String decorativeLine = "########################################";
        String companyName = "Tyler's Pizza Store";
        String name = "Tyler";

        System.out.println(decorativeLine);
        System.out.println();

        System.out.printf("Welcome to %s!\n", companyName);
        System.out.printf("I'm %s. What's your name? ", name);
        String userName = console.nextLine();
        System.out.printf("Here's whats on the menu, %s. Have a look:\n\n", userName);

        String[] itemNames = new String[] {
            "Cheese Pizza",
            "Pepperoni Pizza",
            "Supreme Pizza",
            "Hawaiian Pizza",
            "Veggie Pizza",
            "Meatlover's Pizza",
            "BBQ Chicken Pizza",
            "Medium Drink",
            "Large Drink",
            "Chocolate Chip Cookie"
        };

        Item[] menu = new Item[itemNames.length];

        for(int i = 0; i < menu.length; i++) {
            menu[i] = new Item(i +1, itemNames[i], i + 0.99);
            System.out.println("  " + menu[i]);
           // System.out.printf("  %d. %s\n", i + 1, menuItems[i]);
        }
        System.out.println();
        System.out.println(decorativeLine);

        System.out.print("How many items are in your order? ");
        int numOrder = console.nextInt();

        int [] order = new int[numOrder];

        for (int i = 0; i < numOrder; i++) {
            System.out.printf("What's item #%d? ", i + 1);
            int itemNo = console.nextInt();
            order[i] = itemNo;
        }
        double totalPrice=0;
        for (int i = 0; i < order.length; i++) {
            totalPrice = totalPrice + menu[order[i]].getPrice();
        }
        System.out.printf("\nFinal amount is $%.2f", totalPrice);
    

        System.out.printf("\nAlright! Coming right up! Thank you for your order %s, I hope you have a good rest of your day!\n", userName);

    }
}